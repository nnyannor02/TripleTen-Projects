Superstore Advertising Analysis Project



1\. Tableau Public Dashboard

Link to my dashboard: [Superstore Advertising Analysis Project](https://public.tableau.com/app/profile/nana.serwaah.nyannor/viz/SuperstoreAnalysisProject_nnyannor/ReturnRateofCustomer?publish=yes)



2\. Project Description

This project analyzes the best state-month combinations for advertising based on average profit data from the Superstore dataset.

